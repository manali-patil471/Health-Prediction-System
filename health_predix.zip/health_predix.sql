-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2024 at 05:59 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `health_predix`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `ID` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`ID`, `username`, `password`) VALUES
(1, 'admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `ID` int(11) NOT NULL,
  `Dept_Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`ID`, `Dept_Name`) VALUES
(1, 'Heart health'),
(2, 'Eye Care'),
(3, 'Bone & Joint Health'),
(4, 'Skin Care'),
(5, 'Neurology Department'),
(6, 'Teeth Health');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone_No` bigint(20) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Adhar` bigint(20) NOT NULL,
  `Education` varchar(50) NOT NULL,
  `Specialization` varchar(50) NOT NULL,
  `Experiance` varchar(100) NOT NULL,
  `Dob` date NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `image` varchar(100) NOT NULL,
  `department` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`ID`, `Name`, `Email`, `Phone_No`, `Address`, `Adhar`, `Education`, `Specialization`, `Experiance`, `Dob`, `Username`, `Password`, `gender`, `image`, `department`) VALUES
(2, 'Dr. Rajesh Sharma', 'rajesh@gmail.com', 4567832345, 'Address: 55, Silver Heights, Mumbai, Maharashtra', 1234, 'MBBS', 'Specialization: Electrophysiology', '9 years', '1990-04-06', 'rajesh', '123', 'male', 'upload/2_doctor.png', 1),
(3, 'Dr. Priya Singhania', 'priya@gmail.com', 6789543290, 'Address: 12, Sapphire Gardens, Bangalore, Karnatak', 847583746374, 'BHMS', 'Specialization: Pediatric Cardiology', '4 years', '1923-08-07', 'priya', '123', 'female', 'upload/3_doctor.png', 1),
(4, 'Dr. Sanjay Verma', 'sanjay@gmail.com', 3476892065, 'Address: 33, Emerald Lane, Delhi, Delhi', 1234, 'BHMS', 'Specialization: Cardiothoracic Surgery', '20', '1934-07-05', 'sanjay', '123', 'male', 'upload/4_doctor.png', 1),
(6, 'Dr. Arjun Gupta', 'arjun@gmail.com', 1243658790, 'Address: 8, Sapphire Tower, Chennai, Tamil Nadu', 1234, 'BHMS', 'Specialization: Heart Failure/Cardiomyopathy', '9 years', '1990-05-06', 'arjun', '123', 'male', 'upload/5_doctor.png', 1),
(7, 'Dr. Ananya Patel', 'ananya@gmail.com', 8765434567, '22B, Green Avenue, Kolkata, West Bengal', 6789, 'BHMS', 'Interventional Cardiology', '8 years', '1999-08-07', 'ananya', '123', 'female', 'upload/7_doctor.png', 1),
(8, 'Dr. Neha Kapoor', 'neha@gmail.com', 1232435456, 'Address: 101, Lotus Plaza, Jaipur, Rajasthan', 1234, 'BHMS', 'Specialization: Retina Specialist', '10 years', '1990-07-06', 'neha', '123', 'female', 'upload/8_doctor.png', 2),
(9, 'Dr. Virat Singhania', 'virat@gmail.com', 7698349076, 'Address: 45, Pearl Avenue, Hyderabad, Telangana', 847583746374, 'MBBS', 'Specialization: Cornea and External Disease', '10 years', '2021-07-08', 'virat', '123', 'male', 'upload/9_doctor.png', 2),
(10, 'Dr. Anjali Desai', 'anjali@gmail.com', 9834562137, 'Address: 28, Orchid Heights, Pune, Maharashtra', 847583746374, 'BHMS', 'Specialization: Pediatric Ophthalmology', '9 years', '2020-07-06', 'anjali', '123', 'female', 'upload/10_doctor.png', 2),
(11, 'Dr. Rahul Mehta', 'rahul@gmail.com', 7676788967, 'Address: 15, Sapphire Tower, Ahmedabad, Gujarat', 1234, 'MBBS', 'Specialization: Glaucoma Specialist', '9 years', '1990-08-07', 'rahul', '123', 'male', 'upload/11_doctor.png', 2),
(12, 'Dr. Priyanka Sharma', 'priyanka@gmail.com', 7499204989, 'Address: 7, Rosewood Lane, Kochi, Kerala', 947384736473, 'MBBS', 'Specialization: Oculoplastic Surgery', '4 years', '2018-05-04', 'priyanka', '123', 'female', 'upload/12_doctor.png', 2),
(13, 'Dr. Arvind Gupta', 'arvind@gmail.com', 8756679091, 'Address: 10, Oak Avenue, Lucknow, Uttar Pradesh', 4564, 'MBBS', 'Specialization: Orthopedic Trauma Surgery', '9 years', '2015-07-09', 'arvind', '123', 'male', 'upload/13_doctor.png', 3),
(14, 'Dr. Meenakshi Patel', 'meenakshi@gmail.com', 7499204989, 'Address: 32, Maple Street, Chandigarh, Punjab', 947384736473, 'MBBS', 'Specialization: Spine Surgery', '7years', '2012-05-09', 'meenakshi', '123', 'female', 'upload/14_doctor.png', 3),
(15, 'Dr. Ritesh Kumar', 'ritesh@gmail.com', 3453678907, 'Address: 5, Cedar Heights, Bhopal, Madhya Pradesh', 1234, 'MBBS', 'Specialization: Joint Replacement Surgery', '5years', '2010-05-08', 'ritesh', '123', 'male', 'upload/15_doctor.png', 3),
(16, 'Dr. Priyanka Verma', 'priyanka@gmail.com', 91, 'Address: 14, Pine View, Indore, Madhya Pradesh', 947384736473, 'MBBS', 'Specialization: Pediatric Orthopedics', '8years', '2000-03-06', 'priynka', '123', 'female', 'upload/16_doctor.png', 3),
(17, 'Dr. Siddharth Sharma', 'siddharth@gmail.com', 7499204989, 'Address: 88, Walnut Lane, Nagpur, Maharashtra', 1234, 'MBBS', 'Specialization: Sports Medicine', '3years', '2019-07-08', 'siddharth', '123', 'male', 'upload/17_doctor.png', 3),
(18, 'Dr.Neeraj Chopra', 'neerajchopra@gmail.com', 7499204986, '123 Main Street\r\nGandhi Nagar\r\nBangalore, Karnatak', 1234, 'MBBS', ' Dermatopathology', '10', '1994-02-08', 'neeraj', '123', 'male', 'upload/18_doctor.png', 4),
(19, 'Dr. Neha Gupta', 'nehagupta@gmail.com', 3875638495, '22, Green Avenue, Rajouri Garden, New Delhi, Delhi', 1234, 'MBBS', 'Dermatopathology', '5 years', '1993-07-07', 'neha', '123', 'female', 'upload/19_doctor.png', 4),
(20, 'Dr. Vishal Singh', 'vishalsingh@gmail.com', 63536787327, ' 45, Sunshine Colony, Banjara Hills, Hyderabad, Te', 1234, 'MBBS', 'Pediatric Dermatology', '5years', '1998-12-12', 'vishal', '123', 'male', 'upload/20_doctor.png', 4),
(21, 'Dr.Anushka Sharma', 'anushkasharma@gmail.com', 89358734, '7A, Pearl Plaza, MG Road, Pune, Maharashtra', 3452, 'MBBS', ' Cosmetic Dermatology', '10 years', '1994-07-06', 'anushka', '123', 'male', 'upload/21_doctor.png', 4),
(22, 'Dr.prisha Kale', 'prishakale@gmail.com', 873626765, ' 12, Diamond Tower, Salt Lake City, Kolkata, West ', 6723564754, 'MBBS', 'Dermatologic Oncology', '3 years', '2001-06-05', 'prisha', '123', 'female', 'upload/22_doctor.png', 4),
(23, 'Dr. Aarav Sharma', 'aaravsharma@gmail.com', 9835983265, '123, Green Avenue, New Delhi, India', 1233, 'MBBS', 'Pediatric Neurology', '3 years', '1998-03-12', 'aarav', '123', 'male', 'upload/23_doctor.png', 5),
(24, 'Dr. Maya Patel', 'mayapatel@gmail.com', 3895789426, '456, Sunshine Street, Mumbai, India', 6754, 'MBBS', 'Neurophysiology', '2 years', '1999-10-10', 'maya', '123', 'female', 'upload/24_doctor.png', 5),
(25, 'Dr. Vikram Singhania', 'vikramsinghaniya@gmail.com', 83647329, '789, Serenity Lane, Bangalore, India', 1324, 'MBBS', 'Stroke Neurology', '4 years', '2000-08-10', 'vikram', '123', 'male', 'upload/25_doctor.png', 5),
(26, 'Dr. Priya kale', 'priyakale@gmail.com', 553756734, '101, River View Apartments, Kolkata, India', 5362, 'MBBS', 'Movement Disorders', '7 years', '2001-10-10', 'priya', '123', 'female', 'upload/26_doctor.png', 5),
(27, 'Dr. Rehan Patel', 'rehanpatel@gmail.com', 4567389023, '456 ABC Street, Mumbai, Maharashtra', 1234, 'Bachelor of Dental Surgery (BDS)', 'General Dentistry', '3 yeras', '2000-12-19', 'rehan', '123', 'male', 'upload/27_doctor.png', 6),
(28, 'Dr.Esha Kale', 'eshakale@gmail.com', 4567389022, '123 ABC Street, Mumbai, India', 3456, ': Bachelor of Dental Surgery (BDS) ', 'Orthodontics', '1 years', '1998-12-12', 'esha', '123', 'female', 'upload/28_doctor.png', 6),
(29, 'Dr. Viren Sharma', 'virensharma@gmail.com', 5674867543, '456 XYZ Road, New Delhi, India', 3456, 'Master of Dental Surgery (MDS) in Prosthodontics', 'Prosthodontics', '6 months', '2000-12-12', 'viren', '123', 'male', 'upload/29_doctor.png', 6),
(30, 'Dr. Prathana Singh', 'prathanasingh@gmail.com', 6758493032, '89 LMN Avenue, Kolkata, India', 2345, 'Bachelor of Dental Surgery (BDS)', 'Endodontics', '3 years', '1998-10-10', 'prathana', '123', 'female', 'upload/30_doctor.png', 6),
(31, 'Dr. Rehana Khan', 'rehanakhan@gmail.com', 1452669747, '101 PQR Lane, Bengaluru, India', 5674, 'MDS in Periodontics', 'Periodontics', '2 years', '2000-12-12', 'rehana', '123', 'female', 'upload/31_doctor.png', 6);

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `ID` int(11) NOT NULL,
  `question` varchar(11) NOT NULL,
  `solution` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`ID`, `question`, `solution`) VALUES
(1, '0', '0'),
(2, 'vhbjkbj', '0'),
(3, 'How are you', '0'),
(4, 'bdsm', ''),
(5, 'cbdsjbvsjk', ''),
(6, 'bjb,', '');

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `ID` int(11) NOT NULL,
  `monthly` int(11) NOT NULL,
  `yearly` int(11) NOT NULL,
  `lifetime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`ID`, `monthly`, `yearly`, `lifetime`) VALUES
(1, 100, 5000, 50000);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `ID` int(11) NOT NULL,
  `pat_name` varchar(100) NOT NULL,
  `pat_mail` varchar(70) NOT NULL,
  `pat_phone` bigint(20) NOT NULL,
  `pat_address` varchar(200) NOT NULL,
  `pat_dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `date_upto` date NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`ID`, `pat_name`, `pat_mail`, `pat_phone`, `pat_address`, `pat_dob`, `gender`, `uname`, `pass`, `date_upto`, `status`) VALUES
(1, 'manali ssss', 'manalipatik471@gmail.com', 5655, 'pune', '2024-02-18', 'Female', 'm', 'm', '2025-03-19', 'yes'),
(2, 'rani madam', '', 0, '', '0000-00-00', '', 'r', 'r', '0000-00-00', 'yes'),
(3, 'radha ', 'anujpatil09@gmail.com', 555, 'j', '2024-01-31', 'Female', 'rd', 'rd', '2024-03-18', 'yes'),
(4, 'karuna ', 'kk@gmail.com', 899888, 'mumbai', '2024-02-19', 'Female', 'k', 'k', '2025-03-19', 'yes'),
(5, 'Sayali Kadam', 'sayali@gmail.com', 566728282, 'Ambejogai', '6200-02-07', 'Female', 'dikshu', '123', '2034-02-18', 'yes'),
(6, 'Vaishnavi', 'vasuadnak1621@gmail.com', 8475647586, 'Latur', '0046-03-31', 'Female', 'v', 'v', '2024-03-21', 'yes'),
(7, 'Pallavi ', 'priya.gupta@gamil.com', 74673839, 'kjcdsl', '3829-07-04', 'Female', 'P', 'P', '2024-03-21', 'yes'),
(8, 'Atifa', 'anujpatil09@gmail.com', 48374829, 'kxsl', '0000-00-00', 'Female', 'a', 'a', '2034-02-21', 'yes'),
(9, 'new', 'manalipatik471@gmail.com', 1223, 'ghm', '0006-05-04', 'Female', 'user', 'pass', '2025-02-21', 'yes'),
(10, 'Sunita', 'shravanikale1803@gmail.com', 5745384, 'Latur', '0000-00-00', 'Female', 'sunu', '123', '2024-03-21', 'yes'),
(11, 'Dhanashree', 'dhanashree@gmail.com', 8475657465, 'Latur', '1999-06-07', 'Female', 'd', 'd', '2034-02-23', 'yes'),
(12, 'tanisha Pande', 'tp@gmail.com', 8746872367, 'hjgyu', '2005-02-14', 'Female', 'tanisha', '123', '2024-03-29', 'yes'),
(13, 'zoya', 'zoya@gmail.com', 7483265, 'amgiu', '2024-02-07', 'Female', 'zoya', '123', '2025-03-01', 'yes'),
(14, 'nj', 'hui@gmail.com', 34, 'nk', '1999-01-01', 'Female', 'man', '123', '0000-00-00', 'no'),
(15, 'Shaurya', 's@gmail.com', 679, 'tgyhgj', '1999-01-01', 'Female', 'sh', '123', '2034-03-01', 'yes'),
(16, 'manali', 'manalipatik471@gmail.com', 53674, 'ngehydk', '2024-03-14', 'Female', 'a', '123', '2025-03-02', 'yes'),
(18, 'Manali kale', 'manalipatik471@gmail.com', 4363788393, 'pune', '2024-03-06', 'Female', 's1', '123', '2026-03-22', 'yes'),
(19, 'sneha podar', 'snehapodar@gmail.com', 1325627756, 'j', '2024-03-06', 'Female', 'sneha', '123', '2026-03-22', 'yes'),
(20, 'preeti ', 'preeti@gmail.com', 1234567890, 'pune', '2024-03-15', 'Female', 'pr', '123', '2026-03-21', 'yes'),
(21, 'Shital', 'shital@gmail.com', 7499204989, 'nanded', '2024-03-08', 'Female', 'shital', '123', '2025-03-20', 'yes'),
(22, 'skshi', 'anujpatil09@gmail.com', 5678656767, 'Latur', '2024-03-09', 'Female', 'skshi', '123', '0000-00-00', 'no'),
(23, 'pooja', 'poojazare898@gmail.com', 8978976567, 'college', '2024-03-12', 'Female', 'pooja1', '123', '2024-04-20', 'yes'),
(24, 'Shravani Kale', 'shravanikale1803@gmail.com', 9835983265, 'Near Dayanand College, Latur', '2006-03-18', 'Female', 'shravani', '123', '2044-04-07', 'yes'),
(25, 'ananya', 'anaya@gmail.com', 1234567890, 'latur', '2024-04-02', 'Female', 'a1', '123', '2025-04-16', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `problem`
--

CREATE TABLE `problem` (
  `ID` int(11) NOT NULL,
  `problem` varchar(150) NOT NULL,
  `DOC_ID` int(11) NOT NULL,
  `DEP` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `problem_description` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `problem`
--

INSERT INTO `problem` (`ID`, `problem`, `DOC_ID`, `DEP`, `image`, `problem_description`) VALUES
(1, 'Coronary Artery Disease (CAD)', 2, 1, 'upload/1_issue.png', 'CAD occurs when the blood vessels that supply blood to the heart become narrowed or blocked due to plaque buildup. This can lead to chest pain (angina) and heart attacks.'),
(2, 'Heart Attack', 2, 1, 'upload/2_issue.png', 'A heart attack occurs when the blood flow to a part of the heart is blocked, usually by a blood clot. This can cause damage to the heart muscle and can be life-threatening.'),
(3, 'Arrhythmia', 2, 1, 'upload/3_issue.png', 'Arrhythmia refers to irregular heartbeats, where the heart may beat too fast (tachycardia), too slow (bradycardia), or with an irregular rhythm. This can lead to palpitations, dizziness, or fainting.'),
(4, 'Hypertension (High Blood Pressure)', 2, 1, 'upload/4_issue.png', 'Hypertension is a condition where the force of blood against the artery walls is consistently too high. Over time, this can damage the arteries and lead to heart disease, stroke, and other complicatio'),
(5, 'Atherosclerosis', 2, 1, 'upload/5_issue.png', 'Atherosclerosis is a condition where the arteries become narrowed and hardened due to a buildup of plaque. This restricts blood flow and can lead to heart attacks, strokes, and other vascular diseases'),
(6, 'Congenital Heart Defects', 2, 1, 'upload/6_issue.png', 'Congenital heart defects are present at birth and affect the structure and function of the heart. These defects can range from mild to severe and may require medical intervention or surgery.'),
(7, 'Peripheral Artery Disease (PAD)', 2, 1, 'upload/7_issue.png', 'PAD occurs when there is a narrowing or blockage of the arteries that supply blood to the limbs, usually the legs. This can result in pain, numbness, or weakness in the affected limbs, and increases t'),
(8, 'Blurry Vision', 8, 2, 'upload/8_issue.png', 'Blurry vision refers to difficulty seeing objects sharply and clearly.'),
(9, 'Cloudy Vision (Cataracts)', 8, 2, 'upload/9_issue.png', 'Cloudy Vision (Cataracts)'),
(10, 'Red or Pink Eyes (Conjunctivitis)', 8, 2, 'upload/10_issue.png', 'Red or pink eyes, also known as conjunctivitis, involve inflammation of the conjunctiva, resulting in redness, itching, and discharge.'),
(11, 'Dry, Gritty Eyes (Dry Eye Syndrome)', 8, 2, 'upload/11_issue.png', 'Dry, gritty eyes occur when tears are unable to provide adequate lubrication, leading to discomfort, irritation, and sometimes blurred vision.'),
(12, 'Double Vision (Diplopia)', 8, 2, 'upload/12_issue.png', 'Double vision, or diplopia, involves seeing two images of a single object, which can occur due to problems with eye alignment or neurological issues.'),
(13, 'Flashes and Floaters', 8, 2, 'upload/13_issue.png', 'Flashes and floaters are visual disturbances characterized by seeing flashes of light or dark spots drifting across the field of vision.'),
(14, 'Watery Eyes (Excessive Tearing)', 8, 2, 'upload/14_issue.png', 'Watery eyes, or excessive tearing, can occur due to various factors such as irritation, allergies, or blocked tear ducts.'),
(15, 'Eye Strain', 8, 2, 'upload/15_issue.png', 'Eye strain refers to discomfort or fatigue in the eyes, often associated with prolonged reading, computer use, or other visually demanding tasks.'),
(16, 'Eye Twitching (Blepharospasm)', 8, 2, 'upload/16_issue.png', 'Eye twitching, or blepharospasm, involves involuntary spasms or contractions of the eyelid muscles, often triggered by stress or fatigue.'),
(17, 'Eye Pain or Discomfort', 8, 2, 'upload/17_issue.png', 'Eye pain or discomfort can result from various causes, including infections, injuries, or underlying eye conditions.'),
(18, 'Bone Fractures', 13, 3, 'upload/18_issue.png', 'Bone fractures occur when there is a break or crack in the bone, often resulting from trauma or overuse.'),
(19, 'Arthritis', 13, 3, 'upload/19_issue.png', 'Arthritis refers to inflammation of the joints, leading to pain, stiffness, and reduced mobility.'),
(20, 'Sprains and Strains', 13, 3, 'upload/20_issue.png', 'Sprains involve stretching or tearing of ligaments, while strains involve stretching or tearing of muscles or tendons, often resulting from overexertion or trauma.'),
(21, 'Osteoporosis', 13, 3, 'upload/21_issue.png', 'Osteoporosis is a condition characterized by weakened bones, increasing the risk of fractures, particularly in older adults.'),
(22, 'Tendonitis', 13, 3, 'upload/22_issue.png', 'Tendonitis involves inflammation of tendons, causing pain and tenderness, often due to repetitive motions or overuse.'),
(23, 'Spinal Disorders (e.g., Sciatica, Scoliosis)', 13, 3, 'upload/23_issue.png', 'Spinal disorders encompass various conditions affecting the spine, such as sciatica (nerve pain radiating down the leg) or scoliosis (abnormal curvature of the spine).'),
(24, 'Muscle Cramps and Spasms', 13, 3, 'upload/24_issue.png', 'Muscle cramps and spasms involve sudden, involuntary contractions of muscles, often caused by dehydration, electrolyte imbalances, or muscle fatigue.'),
(25, 'Bursitis', 13, 3, 'upload/25_issue.png', 'Bursitis is inflammation of the bursae, small fluid-filled sacs that cushion and reduce friction between bones and soft tissues in the joints.'),
(26, 'Cartilage Injuries', 13, 3, 'upload/26_issue.png', ' Cartilage injuries involve damage to the connective tissue that cushions the joints, often resulting from trauma or degenerative changes.'),
(27, 'Joint Instability', 13, 3, 'upload/27_issue.png', 'Joint instability occurs when ligaments or other supporting structures around a joint are weakened or damaged, leading to reduced joint stability and increased risk of dislocation or injury.'),
(28, 'Acne', 21, 4, 'upload/28_issue.png', 'Inflammatory condition of the skin characterized by pimples, blackheads, and whiteheads.'),
(29, 'Eczema', 21, 4, 'upload/29_issue.png', 'Chronic skin condition causing itching, redness, and inflammation.'),
(30, 'Psoriasis', 21, 4, 'upload/30_issue.png', ' Autoimmune disease causing thick, red patches with silvery scales on the skin.'),
(31, 'Rosacea', 21, 4, 'upload/31_issue.png', 'Chronic inflammatory skin disorder leading to facial redness and visible blood vessels.'),
(32, 'Dermatitis', 21, 4, 'upload/32_issue.png', 'Inflammation of the skin causing itching, redness, and sometimes blisters.'),
(33, 'Fungal Infections', 21, 4, 'upload/33_issue.png', 'Skin infections caused by fungi, leading to itching, redness, and rashes.'),
(34, 'Migraine Headaches', 23, 5, 'upload/34_issue.png', 'Recurrent headaches often accompanied by nausea, vomiting, and sensitivity to light and sound.'),
(36, 'Epilepsy', 23, 5, 'upload/35_issue.png', 'A disorder characterized by recurrent seizures due to abnormal brain activity.'),
(37, 'Multiple Sclerosis', 25, 5, 'upload/37_issue.png', 'Autoimmune disease causing damage to the myelin sheath in the central nervous system.'),
(38, 'Neuropathy', 24, 5, 'upload/38_issue.png', 'Nerve damage resulting in pain, tingling, and numbness, often in the extremities.'),
(39, 'Trigeminal Neuralgia', 24, 5, 'upload/39_issue.png', 'Intense facial pain, often triggered by touch or movement.'),
(40, 'Tourette Syndrome:', 24, 5, 'upload/40_issue.png', 'Neurological disorder characterized by repetitive, involuntary movements and vocalizations (tics).'),
(41, 'Amyotrophic Lateral Sclerosis (ALS):', 24, 5, 'upload/41_issue.png', ' Progressive degeneration of motor neurons, leading to muscle weakness and paralysis.'),
(42, 'Restless Legs Syndrome', 23, 5, 'upload/42_issue.png', ' Unpleasant sensations in the legs, leading to an irresistible urge to move them.'),
(43, 'Osteoarthritis', 14, 3, 'upload/43_issue.png', 'Osteoarthritis is a degenerative joint disease characterized by the breakdown of cartilage in joints, leading to pain, stiffness, and decreased range of motion.'),
(44, 'Rheumatoid Arthritis:', 15, 3, 'upload/44_issue.png', ' Rheumatoid arthritis is an autoimmune disorder causing chronic inflammation in the joints, leading to pain, swelling, and stiffness.'),
(45, 'Toothache ', 31, 6, 'upload/45_issue.png', 'Pain or discomfort in or around a tooth. It can range from mild to severe and may be caused by various factors such as dental decay, infection, gum disease, or injury.'),
(46, 'Gum Disease (Periodontitis/Gingivitis)', 31, 6, 'upload/46_issue.png', 'Inflammation of the gums, often caused by bacterial infection. It can lead to swollen, red, or bleeding gums, bad breath, receding gums, and eventually tooth loss if left untreated.'),
(47, 'Tooth Decay', 31, 6, 'upload/47_issue.png', 'Destruction of tooth structure due to acids produced by bacteria f');

-- --------------------------------------------------------

--
-- Table structure for table `solution`
--

CREATE TABLE `solution` (
  `ID` int(11) NOT NULL,
  `PROB_ID` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `solution` varchar(1000) NOT NULL,
  `DOC_ID` int(11) NOT NULL,
  `DEP` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `solution`
--

INSERT INTO `solution` (`ID`, `PROB_ID`, `type`, `solution`, `DOC_ID`, `DEP`) VALUES
(1, 1, 2, 'For CAD, we typically recommend lifestyle modifications such as adopting a heart-healthy diet, regular exercise, and medication management to control cholesterol and blood pressure. In some cases, procedures like angioplasty or bypass surgery may be necessary to improve blood flow to the heart.', 2, 1),
(2, 1, 1, 'In adjunct to allopathic treatment, patients may consider homeopathic remedies such as Crataegus (Hawthorn) and Aurum metallicum, which are believed to support heart function and promote overall cardiovascular health.', 2, 1),
(3, 2, 2, 'Immediate treatment for a heart attack involves administering clot-busting medications, performing angioplasty with stent placement, and initiating cardiac rehabilitation post-recovery to prevent further complications.', 2, 1),
(5, 3, 2, 'Management of arrhythmias involves medications such as beta-blockers, calcium channel blockers, or antiarrhythmic drugs. Procedures like cardioversion or catheter ablation may also be utilized to restore normal heart rhythm.', 3, 1),
(6, 3, 1, ' In conjunction with conventional treatment, homeopathic remedies like Aurum metallicum and Crataegus may help regulate heart rhythm and alleviate symptoms such as palpitations and dizziness.', 3, 1),
(7, 4, 1, 'In addition to allopathic management, patients may explore homeopathic remedies like Belladonna and Natrum muriaticum, which are believed to regulate blood pressure and address associated symptoms.', 3, 1),
(8, 4, 2, 'Treatment of hypertension includes lifestyle modifications (diet, exercise) and medications like ACE inhibitors, diuretics, and calcium channel blockers to lower blood pressure.', 3, 1),
(9, 5, 1, 'Homeopathic remedies like Baryta carbonica and Cholesterinum may complement standard treatment by supporting arterial health and improving blood flow.', 4, 1),
(10, 5, 2, 'Management of atherosclerosis involves lifestyle changes, medications like statins to lower cholesterol, and procedures such as angioplasty or bypass surgery in severe cases.', 4, 1),
(11, 6, 2, 'Management of congenital heart defects varies based on the specific defect but may include medications, catheter-based procedures, or corrective surgery.', 4, 1),
(12, 6, 1, 'Adjunctive to conventional therapy, homeopathic remedies like Aurum metallicum and Cactus grandiflorus may help support heart function and alleviate symptoms associated with congenital defects.', 4, 1),
(13, 7, 2, 'Management of PAD includes lifestyle modifications, medications to improve circulation, and in severe cases, procedures like angioplasty or surgery may be recommended.', 6, 1),
(14, 7, 1, 'Homeopathic remedies like Secale cornutum and Arsenicum album may complement allopathic treatment by improving circulation and relieving symptoms associated with PAD.', 6, 1),
(15, 8, 1, 'Homeopathic remedies such as Ruta graveolens or Euphrasia officinalis may be recommended to address underlying causes of blurry vision, promoting overall eye health.', 8, 2),
(16, 9, 1, 'Homeopathic remedies like Calcarea fluorica or Silicea may complement treatment by supporting eye health and potentially slowing the progression of cataracts.', 8, 2),
(17, 8, 2, 'For blurry vision, we often prescribe corrective eyeglasses or contact lenses to help focus light properly onto the retina, improving vision clarity.', 9, 2),
(18, 9, 2, 'Surgical removal of cataracts is the primary treatment, during which the cloudy lens is replaced with an artificial one to restore clear vision.', 9, 2),
(19, 10, 2, 'Treatment typically involves antibiotic eye drops for bacterial conjunctivitis, antihistamines for allergic conjunctivitis, or artificial tears for soothing relief.', 9, 2),
(20, 11, 2, 'Treatment includes artificial tears, prescription eye drops, or procedures like punctal plugs to retain tears and alleviate symptoms.', 9, 2),
(21, 11, 1, 'Homeopathic remedies like Euphrasia or Nux vomica may help restore moisture to the eyes and relieve discomfort associated with dry eye syndrome.', 10, 2),
(22, 12, 1, 'Homeopathic remedies like Physostigma or Gelsemium may be considered to support visual function and address underlying factors contributing to double vision.', 10, 2),
(23, 13, 1, 'Homeopathic remedies like Phosphorus or Arnica montana may help manage symptoms of flashes and floaters, but medical evaluation is crucial to rule out serious retinal issues.', 10, 2),
(24, 12, 2, 'Treatment depends on the underlying cause and may include corrective lenses, vision therapy, or surgical intervention.', 11, 2),
(25, 13, 2, 'Regular eye examinations are essential to monitor for retinal tears or detachment, with surgical intervention if necessary.', 11, 2),
(26, 14, 2, 'Treatment depends on the underlying cause and may involve medications, tear duct plugs, or surgical correction.', 11, 2),
(27, 15, 2, ' Managing screen time, taking regular breaks, and using proper lighting and ergonomic setups can alleviate eye strain.', 11, 2),
(28, 14, 1, 'Homeopathic remedies like Allium cepa or Euphrasia may help regulate tear production and relieve symptoms of excessive tearing, addressing underlying imbalances.', 12, 2),
(29, 14, 1, 'Homeopathic remedies like Ruta graveolens or Arnica may help relieve symptoms of eye strain, especially when associated with overuse or fatigue.', 12, 2),
(30, 16, 1, 'Homeopathic remedies like Agaricus muscarius or Causticum may be considered to address eye twitching, but lifestyle modifications and stress reduction are also essential.', 12, 2),
(31, 17, 1, ' Homeopathic remedies like Belladonna or Spigelia may help alleviate eye pain or discomfort, but consultation with a healthcare professional is recommended for proper diagnosis and treatment.', 12, 2),
(32, 16, 2, 'Stress management techniques, reducing caffeine intake, and addressing underlying factors can help alleviate eye twitching.', 8, 2),
(33, 17, 2, 'Treatment depends on the underlying cause and may involve pain relievers, antibiotics, or other targeted therapies.', 8, 2),
(34, 1, 1, 'ffssdsf', 2, 1),
(35, 1, 2, 'nbjk', 2, 1),
(36, 1, 2, ' nm', 2, 1),
(37, 18, 1, 'Homeopathic remedies like Symphytum or Calcarea phosphorica may aid in fracture healing and reduce associated pain and inflammation.', 13, 3),
(38, 19, 1, 'Homeopathic remedies like Rhus toxicodendron or Bryonia may help alleviate arthritis symptoms and improve joint function.', 13, 3),
(39, 26, 2, 'Treatment may include rest, physical therapy, and in some cases, surgical repair or replacement of damaged cartilage.', 13, 3),
(40, 27, 2, 'Treatment involves strengthening exercises, bracing, and sometimes surgical repair to restore joint stability.', 13, 3),
(41, 28, 2, 'Topical creams containing benzoyl peroxide, retinoids, or antibiotics. Oral medications like antibiotics or isotretinoin.', 21, 4),
(42, 28, 1, ' Remedies like Hepar sulph, Silicea, Kali bromatum, or Sulphur might be prescribed based on individual symptoms.', 21, 4),
(43, 29, 2, 'Moisturizers, corticosteroid creams, antihistamines, and in severe cases, immunosuppressants.', 21, 4),
(44, 29, 1, ' Remedies like Graphites, Sulphur, Arsenicum album, or Mezereum may be recommended, based on the presentation of symptoms.', 21, 4),
(45, 30, 2, 'Topical treatments like corticosteroids, vitamin D analogs, or tar-based products. Systemic medications like methotrexate, cyclosporine, or biologics.', 21, 4),
(46, 30, 1, 'Remedies such as Arsenicum album, Sepia, Sulphur, or Kali arsenicosum may be suggested, depending on the symptoms.', 21, 4),
(47, 31, 2, 'Topical medications like metronidazole or azelaic acid. Oral antibiotics or isotretinoin in severe cases.', 21, 4),
(48, 32, 2, 'Avoiding triggers, topical corticosteroids, moisturizers, and antihistamines.', 21, 4),
(49, 32, 1, 'Remedies like Rhus toxicodendron, Graphites, Sulphur, or Arsenicum album might be recommended, depending on the type and presentation of dermatitis.', 21, 4),
(50, 0, 2, 'Antifungal creams or oral medications.', 21, 4),
(51, 28, 1, 'Remedies like Hepar sulphuris calcareum, Silicea, Kali bromatum, or Sulphur, prescribed based on individual symptoms and constitution', 18, 4),
(52, 28, 2, 'Topical treatments like benzoyl peroxide, retinoids, or antibiotics. Oral medications such as antibiotics or isotretinoin.', 18, 4),
(53, 29, 2, ' Moisturizers, corticosteroid creams, antihistamines, and in severe cases, immunosuppressants.', 18, 4),
(54, 31, 2, 'Topical medications like metronidazole or azelaic acid. Oral antibiotics or isotretinoin in severe cases.', 18, 4),
(55, 33, 2, 'Antifungal creams or oral medications.', 18, 4),
(56, 28, 1, ' Remedies like Hepar sulphuris calcareum, Silicea, Kali bromatum, or Sulphur, prescribed based on individual symptoms, acne type (e.g., inflammatory, cystic), and overall health.', 20, 4),
(57, 32, 2, ' Topical corticosteroids, moisturizers, or barrier creams to reduce inflammation and itching. Antihistamines for symptom relief. Identifying and avoiding triggers.', 20, 4),
(58, 32, 1, 'Remedies such as Rhus toxicodendron, Graphites, Sulphur, or Arsenicum album, prescribed based on the type of dermatitis (e.g., contact dermatitis, atopic dermatitis), individual symptoms, and constitutional characteristics.', 20, 4),
(59, 33, 2, ' Antifungal medications in the form of creams, ointments, or oral tablets. Common antifungals include clotrimazole, terbinafine, or fluconazole.', 20, 4),
(60, 30, 2, 'Topical treatments such as corticosteroids, vitamin D analogs (calcipotriene), retinoids (tazarotene), or coal tar preparations. Systemic medications like methotrexate, cyclosporine, or biologics (adalimumab, etanercept) for severe cases.', 22, 4),
(61, 30, 1, ' Remedies like Arsenicum album, Sepia, Sulphur, or Kali arsenicosum, prescribed based on individual symptoms, psoriasis type (e.g., plaque, guttate), and constitutional characteristics.', 22, 4),
(62, 29, 2, ' Moisturizers, topical corticosteroids (hydrocortisone, triamcinolone), calcineurin inhibitors (tacrolimus, pimecrolimus), or crisaborole for mild to moderate cases. Systemic medications like oral corticosteroids or immunosuppressants for severe cases.', 22, 4),
(63, 29, 1, 'Remedies such as Graphites, Sulphur, Arsenicum album, or Mezereum, prescribed based on individual symptoms, eczema type (e.g., atopic dermatitis, contact dermatitis), and constitutional characteristics.', 22, 4),
(64, 34, 1, ' Remedies like Belladonna, Iris versicolor, or Natrum muriaticum, tailored to individual symptoms and constitutional characteristics', 23, 5),
(65, 34, 2, 'Medications such as triptans, NSAIDs, and anti-emetics, along with lifestyle modifications.', 23, 5),
(66, 35, 1, 'Remedies such as Cicuta virosa, Cuprum metallicum, or Bufo rana, selected based on seizure type, triggers, and individual constitution.', 23, 5),
(67, 36, 1, 'Remedies such as Cicuta virosa, Cuprum metallicum, or Bufo rana, selected based on seizure type, triggers, and individual constitution.', 23, 5),
(68, 36, 2, 'Anti-epileptic drugs (AEDs) like carbamazepine, valproate, or lamotrigine, sometimes supplemented with surgery or vagus nerve stimulation.', 23, 5),
(69, 8, 2, 'If blurry vision is due to refractive errors (such as myopia, hyperopia, or astigmatism), an optometrist may prescribe corrective lenses (glasses or contact lenses) to improve visual clarity.', 12, 2),
(70, 9, 2, 'The primary treatment for cataracts in allopathy is surgical intervention. Cataract surgery involves removing the cloudy lens and replacing it with an artificial intraocular lens. This surgery is highly effective in restoring clear vision.', 12, 2),
(71, 1, 2, 'Medications (statins, beta-blockers), angioplasty, coronary artery bypass grafting (CABG).', 3, 1),
(72, 1, 1, ' Remedies like Crataegus, Aurum metallicum, or Digitalis may be considered as complementary support.', 3, 1),
(73, 2, 2, 'In the event of a heart attack, immediate emergency medical attention is essential. Standard allopathic treatments may include administering medications like aspirin and nitroglycerin, performing emergency procedures such as angioplasty with stent placement, or, in severe cases, coronary artery bypass grafting (CABG) surgery.', 3, 1),
(74, 2, 1, 'While homeopathy is not a primary treatment for acute conditions like a heart attack, some homeopathic practitioners might recommend Arnica montana as a supportive remedy for post-heart attack recovery. Arnica is believed by some to have anti-inflammatory properties and may be suggested to aid in reducing inflammation and promoting healing. However, the use of homeopathic remedies in such critical situations is controversial, and it is essential to prioritize immediate allopathic emergency care. Always consult with qualified healthcare professionals for personalized advice.', 3, 1),
(75, 4, 2, 'Allopathic treatment for hypertension often includes medications such as ACE inhibitors (e.g., Lisinopril), which help relax blood vessels and lower blood pressure.', 3, 1),
(76, 4, 1, 'A homeopathic practitioner might consider prescribing Natrum muriaticum for hypertension, especially if emotional stress and a tendency to retain fluids are prominent symptoms.', 3, 1),
(77, 5, 2, 'Statins, such as Atorvastatin or Simvastatin, are commonly prescribed to lower cholesterol levels and manage atherosclerosis.', 3, 1),
(78, 5, 1, 'The homeopathic remedy Aurum metallicum might be considered in cases of atherosclerosis, especially when there are symptoms of arterial degeneration and calcification.', 3, 1),
(79, 7, 2, 'Allopathic treatment for peripheral artery disease often includes medications like antiplatelet drugs (aspirin or clopidogrel), statins to manage cholesterol levels, and sometimes surgical interventions such as angioplasty or bypass surgery.', 3, 1),
(80, 7, 1, 'In homeopathy, the remedy Crataegus may be considered for peripheral artery disease, especially when there are symptoms such as cramping pain in the legs and difficulty walking.', 3, 1),
(81, 37, 2, ' Disease-modifying drugs.', 25, 5),
(82, 37, 1, 'Gelsemium, Lachesis, or Plumbum metallicum for symptom relief.', 25, 5),
(83, 34, 2, 'Medications like triptans, beta-blockers.', 25, 5),
(84, 34, 1, 'Belladonna, Iris versicolor, or Natrum muriaticum for symptom relief.', 25, 5),
(85, 36, 1, 'Belladonna, Iris versicolor, or Natrum muriaticum for symptom relief.', 25, 5),
(86, 41, 1, 'Conium, Gelsemium, or Lathyrus sativus for symptom relief.', 24, 5),
(87, 41, 2, 'Supportive care, riluzole.', 24, 5),
(88, 40, 2, 'Behavioral therapy, antipsychotics.', 24, 5),
(89, 40, 1, ' Cina, Hyoscyamus, or Tuberculinum may be considered.', 24, 5),
(90, 39, 2, 'Anticonvulsants, surgical procedures.', 24, 5),
(91, 39, 1, ' Spigelia, Magnesia phosphorica, or Belladonna for pain relief.', 24, 5),
(92, 38, 2, 'Medications, physical therapy.', 24, 5),
(93, 38, 1, 'Hypericum, Arsenicum album, or Staphysagria for nerve-related symptoms.', 24, 5),
(94, 42, 1, 'Zincum metallicum, Rhus toxicodendron, or Pulsatilla for symptom relief.', 23, 5),
(95, 42, 2, 'Medications, lifestyle changes.', 23, 5),
(96, 41, 2, ' Riluzole for disease modification.', 23, 5),
(97, 41, 1, ' Aconitum napellus, Lathyrus sativus, or Phosphorus for symptom relief.', 23, 5),
(98, 39, 2, ' Microvascular decompression surgery.', 23, 5),
(99, 39, 1, 'Mezereum, Magnesia phosphorica, or Verbascum for pain relief.', 23, 5),
(100, 38, 2, 'Topical analgesics, anticonvulsants (pregabalin), tricyclic antidepressants ', 23, 5),
(101, 38, 1, 'Kali phosphoricum, Rhus toxicodendron, or Arsenicum album for nerve-related ', 23, 5),
(102, 36, 2, ' Newer antiepileptic drugs like levetiracetam or lamotrigine.', 23, 5),
(103, 36, 1, 'Artemisia vulgaris, Bufo rana, or Zincum metallicum for seizure control.', 23, 5),
(104, 21, 2, 'Treatment often involves medications such as bisphosphonates, hormone therapy, or calcium and vitamin D supplements. Lifestyle modifications such as exercise and dietary changes are also recommended.', 14, 3),
(105, 21, 1, 'Homeopathic remedies for osteoporosis might include Calcarea carbonica, Silicea, Calcarea phosphorica, or Symphytum. However, evidence supporting their efficacy is limited.', 14, 3),
(106, 43, 2, 'Allopathic treatment typically involves pain relievers, nonsteroidal anti-inflammatory drugs (NSAIDs), corticosteroid injections, physical therapy, and in severe cases, joint replacement surgery.', 14, 3),
(107, 43, 1, ' Homeopathic remedies such as Rhus toxicodendron, Bryonia, Arnica montana, or Ruta graveolens may be prescribed. However, evidence for their effectiveness is lacking.', 14, 3),
(108, 18, 2, ' Allopathic treatment involves immobilization (casting or splinting) of the affected area, pain management, and possibly surgical intervention for severe fractures. Physical therapy is often prescribed for rehabilitation.', 14, 3),
(109, 18, 1, 'Homeopathic remedies such as Symphytum, Arnica montana, Calcarea phosphorica, or Ruta graveolens may be used to aid in healing. However, their efficacy is not well-supported by scientific evidence.', 14, 3),
(110, 20, 2, ' Over-the-counter NSAIDs like ibuprofen or naproxen can help alleviate pain and reduce inflammation.', 14, 3),
(111, 0, 2, 'Rest: Avoiding activities that exacerbate symptoms to allow the tendon to heal. Ice: Applying ice packs to the affected area for 15-20 minutes several times a day to reduce inflammation and pain. Nonsteroidal anti-inflammatory drugs (NSAIDs): Over-the-counter medications such as ibuprofen or naproxen can help reduce pain and inflammation. Physical therapy: Specific exercises to stretch and strengthen the affected tendon and surrounding muscles. Corticosteroid injections: In some cases, injections of corticosteroids directly into the tendon sheath can provide relief from pain and inflammation.', 14, 3),
(112, 0, 2, 'Massage: Massaging the cramped muscle can help relax it and alleviate discomfort. Hydration: Drinking fluids, particularly water or electrolyte-containing beverages, can help prevent dehydration and electrolyte imbalances that contribute to muscle cramps. Electrolyte supplementation: In cases of electrolyte imbalances, consuming foods or drinks rich in potassium, magnesium, calcium, and sodium may be beneficial. Heat or cold therapy: Applying heat or cold packs to the affected muscle can help reduce pain and promote relaxation. Medications: Over-the-counter pain relievers such as acetaminophen or ibuprofen may help alleviate pain associated with muscle cramps.', 14, 3),
(113, 24, 1, 'Cuprum Metallicum: This remedy is often indicated for muscle cramps and spasms, particularly in the calves or feet, accompanied by coldness and stiffness. Magnesia Phosphorica: Useful for muscle cramps that are relieved by warmth and pressure, especially in the abdomen or menstrual cramps. Rhus Toxicodendron: Helpful for muscle cramps and spasms that are worse at the beginning of movement and improve with continued motion, often accompanied by stiffness and soreness.', 14, 3),
(114, 25, 2, 'Rest: Avoiding activities that aggravate the affected joint to allow it to rest and heal. Ice: Applying ice packs to the affected area for 15-20 minutes several times a day to reduce inflammation and pain. Nonsteroidal anti-inflammatory drugs (NSAIDs): Over-the-counter medications such as ibuprofen or naproxen can help reduce pain and inflammation. Physical therapy: Specific exercises to stretch and strengthen the muscles around the affected joint, improving flexibility and reducing strain on the bursa.', 15, 3),
(115, 25, 1, 'Apis Mellifica: This remedy is often indicated for bursitis with sudden, sharp pains that are burning or stinging in nature, accompanied by swelling and heat. Bryonia Alba: Useful for bursitis with stitching pains that worsen with movement and are relieved by rest, often associated with stiffness.', 15, 3),
(116, 24, 1, 'Magnesia Phosphorica: Useful for muscle cramps that are relieved by warmth and pressure, especially in the abdomen or menstrual cramps. Rhus Toxicodendron: Helpful for muscle cramps and spasms that are worse at the beginning of movement and improve with continued motion, often accompanied by stiffness and soreness. Nux Vomica: Indicated for muscle cramps and spasms triggered by overexertion, stress, or dietary indiscretions, often associated with digestive disturbances.', 15, 3),
(117, 22, 1, 'Bryonia Alba: When tendinitis is associated with sharp, stitching pains that worsen with movement and are relieved by rest, Bryonia may be helpful. Rhus Toxicodendron: Useful for tendinitis where there is stiffness and pain, especially at the beginning of movement, which improves with continued motion. Arnica Montana: This remedy can be beneficial for tendinitis accompanied by bruising and soreness.', 15, 3),
(118, 20, 2, ' NSAIDs or acetaminophen can be used for pain relief.', 15, 3),
(119, 20, 1, 'Bryonia alba can be beneficial for pain that worsens with movement and improves with rest.', 15, 3),
(120, 20, 1, 'Ruta graveolens may aid in healing ligaments, tendons, or the periosteum, particularly in chronic or recurrent cases.', 15, 3),
(121, 44, 2, 'Treatment typically involves disease-modifying antirheumatic drugs (DMARDs), corticosteroids, NSAIDs, and biologic agents, along with physical therapy and lifestyle changes.', 15, 3),
(122, 44, 1, 'Remedies such as Rhus toxicodendron, Bryonia, Pulsatilla, or Causticum might be prescribed. However, evidence supporting their efficacy is minimal.', 15, 3),
(123, 25, 2, 'Physical Therapy: A physical therapist can design an exercise program to stretch and strengthen the muscles around the affected joint, reducing strain on the bursa. Ultrasound Therapy: Ultrasound waves can help reduce inflammation and promote healing in the affected bursa.', 16, 3),
(124, 25, 1, 'Hypericum perforatum: Useful for bursitis with shooting or sharp pains, especially when nerves are involved.  Belladonna: Indicated for bursitis with sudden onset, intense inflammation, and throbbing pain, often worsened by touch or movement.', 16, 3),
(125, 27, 2, 'Physical Therapy: A structured physical therapy program can help strengthen the muscles around the unstable joint, improve proprioception, and enhance joint stability through specific exercises, stretches, and manual therapy techniques.  Bracing or Taping: Orthopedic braces or taping techniques can provide external support to the unstable joint, reducing excessive movement and helping to prevent injuries.', 16, 3),
(126, 27, 1, 'Rhus Toxicodendron: This remedy is often indicated for joint instability with stiffness and pain that worsens with initial movement but improves with continued motion. It can be particularly beneficial for unstable joints due to overexertion or injury.  Bryonia Alba: Useful for joint instability with stitching pains that worsen with movement and are relieved by rest. It can be indicated for unstable joints aggravated by sudden movements or exertion.', 16, 3),
(127, 26, 2, 'strengthen surrounding muscles, and stabilize the affected joint after a cartilage injury.  Nonsteroidal Anti-Inflammatory Drugs (NSAIDs): Over-the-counter medications like ibuprofen or naproxen can help reduce inflammation and alleviate pain associated with cartilage injuries.  Corticosteroid Injections: Injections of corticosteroids directly into the affected joint can help ', 16, 3),
(128, 0, 0, 'Symphytum: This remedy is often indicated for injuries to the bones or cartilage, particularly when there is a sensation of bruising, soreness, or aching in the affected area. Symphytum can aid in promoting healing and reducing pain associated with cartilage injuries.  Ruta Graveolens: Useful for cartilage injuries with stiffness, soreness, and bruising, especially in the wrists, knees, or ankles. Ruta can help improve flexibility and reduce inflammation in the affected joint.', 16, 3),
(129, 27, 2, 'Corticosteroid Injections: Injections of corticosteroids directly into the affected joint can help reduce inflammation and provide temporary relief from pain and discomfort associated with cartilage injuries.  Hyaluronic Acid Injections: Intra-articular injections of hyaluronic acid can help lubricate the joint and provide relief from symptoms of cartilage injuries, particularly in cases of osteoarthritis.', 17, 3),
(130, 27, 1, 'Calcarea Fluorica: Indicated for chronic or recurrent cartilage injuries, particularly those involving the knee or other weight-bearing joints. Calcarea fluorica can help strengthen weakened cartilage and improve joint function over time.  Arnica Montana: Helpful for acute cartilage injuries with bruising, swelling, and tenderness, particularly after trauma or overexertion. Arnica can aid in reducing inflammation and promoting healing in the affected joint.', 17, 3),
(131, 26, 1, 'Calcarea Fluorica: Indicated for chronic or recurrent cartilage injuries, particularly those involving the knee or other weight-bearing joints. Calcarea fluorica can help strengthen weakened cartilage and improve joint function over time.  Arnica Montana: Helpful for acute cartilage injuries with bruising, swelling, and tenderness, particularly after trauma or overexertion. Arnica can aid in reducing inflammation and promoting healing in the affected joint.', 17, 3),
(132, 26, 2, 'Hyaluronic Acid Injections: Intra-articular injections of hyaluronic acid can help lubricate the joint and provide relief from symptoms of cartilage injuries, particularly in cases of osteoarthritis.  Surgery: In severe cases of cartilage injuries, surgical procedures such as arthroscopic debridement, microfracture, autologous chondrocyte implantation (ACI), or osteochondral allograft transplantation may be necessary to repair or replace damaged cartilage and restore joint function.', 17, 3),
(133, 24, 2, 'Heat or cold therapy: Applying heat or cold packs to the affected muscle can help reduce pain and promote relaxation. Medications: Over-the-counter pain relievers such as acetaminophen or ibuprofen may help alleviate pain associated with muscle cramps.', 17, 3),
(134, 24, 1, 'Rhus Toxicodendron: Helpful for muscle cramps and spasms that are worse at the beginning of movement and improve with continued motion, often accompanied by stiffness and soreness. Nux Vomica: Indicated for muscle cramps and spasms triggered by overexertion, stress, or dietary indiscretions, often associated with digestive disturbances.', 17, 3),
(135, 45, 2, 'Pain relievers such as ibuprofen or acetaminophen, antibiotics if infection is present, dental procedures such as fillings, root canals, or extractions.', 31, 6),
(136, 45, 1, 'Belladonna, Chamomilla, Coffea cruda, Plantago, Arnica montana. Selection of remedy depends on the specific symptoms like sensitivity, throbbing pain, aggravation by hot or cold, etc.', 31, 6),
(137, 46, 2, 'Professional dental cleaning, scaling and root planing, antibiotics, and in severe cases, surgical procedures.', 31, 6),
(138, 46, 1, ' Mercurius solubilis, Silicea, Hepar sulphuris, Kreosotum, Myristica sebifera. Remedies are chosen based on symptoms like bleeding gums, pus formation, bad breath, etc.', 31, 6),
(139, 47, 1, ' Staphysagria, Calcarea fluorica, Kreosotum, Acidum nitricum, Antimonium crudum. Remedies are chosen based on individual symptoms like tooth sensitivity, cavities, etc.', 31, 6),
(140, 47, 2, 'Fillings, crowns, root canal treatment for severe cases, fluoride treatment for prevention, and good oral hygiene practices.', 31, 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `problem`
--
ALTER TABLE `problem`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `solution`
--
ALTER TABLE `solution`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `problem`
--
ALTER TABLE `problem`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `solution`
--
ALTER TABLE `solution`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=141;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
